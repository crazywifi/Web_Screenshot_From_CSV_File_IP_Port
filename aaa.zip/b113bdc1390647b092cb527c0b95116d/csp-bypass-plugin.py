"""
@author: moloch

A basic Content Security Policy parser.
"""
# pylint: disable=C0103,C0111,R0201

from collections import defaultdict
from urlparse import urlparse

### Constants
BASE_URI = "base-uri"
FORM_ACTION = "form-action"
FRAME_ANCESTORS = "frame-ancestors"
PLUGIN_TYPES = "plugin-types"
REPORT_URI = "report-uri"
SANDBOX = "sandbox"
UPGRADE_INSECURE_REQUESTS = "upgrade-insecure-requests"
REFLECTIVE_XSS = "reflected-xss"
REFERRER = "referrer"

DEFAULT_SRC = "default-src"
SCRIPT_SRC = "script-src"
CHILD_SRC = "child-src"
FRAME_SRC = "frame-src"
CONNECT_SRC = "connect-src"
FONT_SRC = "font-src"
IMG_SRC = "img-src"
MEDIA_SRC = "media-src"
OBJECT_SRC = "object-src"
STYLE_SRC = "style-src"
MANIFEST_SRC = "manifest-src"

SELF = "'self'"
NONE = "'none'"
UNSAFE_INLINE = "'unsafe-inline'"
UNSAFE_EVAL = "'unsafe-eval'"
HTTP = "http:"
HTTPS = "https:"
BLOB = "blob:"
DATA = "data:"
FILESYSTEM = "filesystem:"
MEDIASTREAM = "mediastream:"


def csp_match_domains(content_src, domain):
    """ Does a `content_src' allow a `domain' """
    # Isolate just the domain incase there is a scheme/etc.
    content_src = content_src.lower()
    domain = domain.lower()
    if urlparse(content_src).netloc != '':
        content_src = urlparse(content_src).netloc

    src_parts = content_src.split(".")[::-1]  # Reverse the domains
    domain_parts = domain.split(".")[::-1]
    for index, src_part in enumerate(src_parts):
        if src_part == "*":
            return True
        if src_part == domain_parts[index]:
            continue
        else:
            return False
    return len(src_parts) == len(domain_parts)


class ContentSecurityPolicy(object):

    """
    A simple Content-Security-Policy object, it resembles a dictionary but has
    logic to return `default-src' when approiate, etc.
    """

    HEADERS = ["content-security-policy",
               "content-security-policy-report-only",
               "x-content-security-policy",
               "x-webkit-csp"]

    # All content directives
    CONTENT_DIRECTIVES = [
        DEFAULT_SRC, SCRIPT_SRC, CHILD_SRC, FRAME_SRC, CONNECT_SRC, FONT_SRC,
        IMG_SRC, MEDIA_SRC, OBJECT_SRC, STYLE_SRC, MANIFEST_SRC,

        BASE_URI, FORM_ACTION, FRAME_ANCESTORS, PLUGIN_TYPES,
        REPORT_URI, SANDBOX, REFLECTIVE_XSS, REFERRER]

    # These directives do not fallback to default-src
    NO_FALLBACK = [BASE_URI, FORM_ACTION, FRAME_ANCESTORS, PLUGIN_TYPES,
                   REPORT_URI, SANDBOX, REFLECTIVE_XSS, REFERRER]

    def __init__(self, header_name, header_value):
        self._content_policies = defaultdict(list)
        self._header_name = None
        self._header_value = None
        self.header_name = header_name
        self.header_value = header_value

    @property
    def header_name(self):
        return self._header_name

    @header_name.setter
    def header_name(self, value):
        """ Setter for the header name """
        if value.lower() not in self.HEADERS:
            raise ValueError("Unknown header name: '%s'" % value)
        else:
            self._header_name = value.lower()

    @property
    def header_value(self):
        return self._header_value

    @header_value.setter
    def header_value(self, value):
        """ Sets the header value and parses it """
        self._header_value = value.lower()
        self._parse_header()

    def _parse_header(self):
        """ Splits the header on ';' then subsequently on whitespace """
        for policy in self._header_value.split(";"):
            if not len(policy):
                continue  # Skip blanks
            directive, sources = self._unpack_policy(*policy.strip().split(" "))
            self[directive] = sources

    def _unpack_policy(self, directive, *content_sources):
        """ Used to unpack the directive name and directives """
        return directive, [src.strip() for src in content_sources]

    def is_deprecated_header(self):
        """ Check for X-WebKit-CSP or X-Content-Security-Policy """
        return self.header_name.startswith('x')

    def is_report_only_mode(self):
        return self.header_name.endswith("report-only")

    def iteritems(self):
        """ Similar to a dictionary, iterates tuples of key/value pairs """
        for key in self.CONTENT_DIRECTIVES:
            yield (key, self[key],)

    def __setitem__(self, key, value):
        if key not in self.CONTENT_DIRECTIVES:
            raise ValueError("Unknown directive '%s'" % key)
        if isinstance(value, list):
            self._content_policies[key].extend(value)
        elif isinstance(value, basestring):
            self._content_policies[key].append(value)
        else:
            raise ValueError("Expected list or basestring")

    def __getitem__(self, key):
        """
        Get the policy or return default-src if the policy isn't in NO_FALLBACK
        """
        if key not in self.CONTENT_DIRECTIVES:
            raise ValueError("Unknown directive '%s'" % key)
        if key in self._content_policies:
            return self._content_policies[key]
        elif key not in self.NO_FALLBACK:
            return self._content_policies[DEFAULT_SRC]

    def __contains__(self, item):
        if item not in self.NO_FALLBACK and item in self.CONTENT_DIRECTIVES:
            return True
        else:
            return item in self._content_policies

    def __iter__(self):
        for key in self.CONTENT_DIRECTIVES:
            yield key
"""
Common domains that contain known CSP bypasses
"""
# pylint: disable=C0301


CSP_KNOWN_BYPASSES = {
    "script-src": [
        # (DOMAIN, DESCRIPTION/EXAMPLE,)
        ("ajax.googleapis.com", '''
Additional information is available here:  https://github.com/cure53/XSSChallengeWiki/wiki/H5SC-Minichallenge-3:-%22Sh*t,-it%27s-CSP!%22

Example Payload:
"><script src=//ajax.googleapis.com/ajax/services/feed/find?v=1.0%26callback=alert%26context=1337></script>
'''),
    ]
}
"""
@author: moloch

Scanner issues reported by the plugin.
"""
# pylint: disable=E0602,C0103,W0621,R0201


from burp import IScanIssue


class BaseCSPIssue(IScanIssue):

    """
    Just a base class with some helpful docstrings and a slightly modified
    constructor so we can track what directive we're reporting about.
    """

    # pylint: disable=R0913
    def __init__(self, httpService, url, httpMessages, severity, confidence,
                 directive=None):
        """
        Setters for all the getters, `directive' is optional
        """
        self._httpService = httpService
        self._url = url
        self._httpMessages = httpMessages
        self._severity = severity
        self._confidence = confidence
        self._directive = directive

    def getUrl(self):
        """
        This method returns the URL for which the issue was generated.
        @return The URL for which the issue was generated.
        """
        return self._url

    def getIssueName(self):
        """
        This method returns the name of the issue type.
        @return The name of the issue type (e.g. "SQL injection").
        """
        raise NotImplementedError()

    def getIssueType(self):
        """
        This method returns a numeric identifier of the issue type. See the Burp
        Scanner help documentation for a listing of all the issue types.
        @return A numeric identifier of the issue type.
        """
        return 0  # https://portswigger.net/burp/help/scanner_issuetypes.html

    def getSeverity(self):
        """
        This method returns the issue severity level.
        @return The issue severity level. Expected values are "High", "Medium",
        "Low", "Information" or "False positive".
        """
        return self._severity

    def getConfidence(self):
        """
        This method returns the issue confidence level.
        @return The issue confidence level. Expected values are "Certain", "Firm"
        or "Tentative".
        """
        return self._confidence

    def getIssueBackground(self):
        """
        This method returns a background description for this type of issue.
        @return A background description for this type of issue, or
        <code>null</code> if none applies.
        """
        return """
Content security policy (CSP) is an HTML5 standard primarily designed to mitigate
the issue of cross-site scripting (XSS) and other content injection vulnerabilities
within web applications. Weak content security policies stem from overly permissive
or ineffective content source directives.
"""

    def getRemediationBackground(self):
        """
        This method returns a background description of the remediation for this
        type of issue.
        @return A background description of the remediation for this type of
        issue, or
        <code>null</code> if none applies.
        """
        return """
While non-trivial to implement, modern browser headers such
as Content-Security-Policy (CSP) can provide extremely robust protection against
XSS and related content injection issues. To fix weak policies enforce as much
restriction on the content sources as possible, strive to disable unsafe, insecure,
and wildcard sources, and where possible limit 3rd party domains.
"""

    def getIssueDetail(self):
        """
        This method returns detailed information about this specific instance of
        the issue.
        @return Detailed information about this specific instance of the issue,
        or
        <code>null</code> if none applies.
        """
        raise NotImplementedError()

    def getRemediationDetail(self):
        """
        This method returns detailed information about the remediation for this
        specific instance of the issue.
        @return Detailed information about the remediation for this specific
        instance of the issue, or
        <code>null</code> if none applies.
        """
        raise NotImplementedError()

    def getHttpMessages(self):
        """
        This method returns the HTTP messages on the basis of which the issue was
        generated.
        @return The HTTP messages on the basis of which the issue was generated.
        Note: The items in this array should be instances of
        <code>IHttpRequestResponseWithMarkers</code> if applicable, so that
        details of the relevant portions of the request and response messages are
        available.
        """
        if isinstance(self._httpMessages, list):
            return self._httpMessages
        else:
            return [self._httpMessages]

    def getHttpService(self):
        """
        This method returns the HTTP service for which the issue was generated.
        @return The HTTP service for which the issue was generated.
        """
        return self._httpService


class WildcardContentSource(BaseCSPIssue):

    """
    Wildcard content sources. Note: this does not flag wildcard subdomains
    """

    def getIssueName(self):
        return "Wildcard Content Source: %s" % self._directive

    def getIssueDetail(self):
        return "The %s CSP directive does not enforce any restrictions on what \
        origins content can be loaded from." % self._directive

    def getRemediationDetail(self):
        return "Remove all wildcards from the content security policy."


class WildcardSubdomainContentSource(BaseCSPIssue):

    """
    Wildcard subdomain content sources.
    """

    def getIssueName(self):
        return "Wildcard Subdomain Content Source: %s" % self._directive

    def getIssueDetail(self):
        return "Wildcard subdomains expose additional attack surface, since an \
        attacker can potentially leverage a vulnerability in any subdomain to \
        to bypass the CSP."

    def getRemediationDetail(self):
        return "Avoid use of wildcard subdomains in CSP directives."


class UnsafeContentSource(BaseCSPIssue):

    """ Any directive that allows unsafe content (e.g. 'unsafe-eval') """

    def getIssueName(self):
        return "Unsafe Content Source: %s" % self._directive

    def getIssueDetail(self):
        return "This content security policy allows for unsafe content sources"

    def getRemediationDetail(self):
        return "Refactor the website to remove inline JavaScript and CSS"


class InsecureContentDirective(BaseCSPIssue):

    """
    Any directive that allows insecure network protocols (e.g. ws: or http:)
    """

    def getIssueName(self):
        return "Insecure Content Source: %s" % self._directive

    def getIssueDetail(self):
        return "The content directive %s allows resources to be loaded over \
        insecure network protocols." % self._directive

    def getRemediationDetail(self):
        return "Restrict content sources to only use secure protocols such as \
        https:// and wss://."


class MissingDirective(BaseCSPIssue):

    """
    Directives that 'fail open', that is to say they are not restricted by the
    CSP and do not fallback to `default-src'.
    """

    def getIssueName(self):
        return "Missing CSP Directive: %s" % self._directive

    def getIssueDetail(self):
        return "The %s content directive does not fallback to default-src, if \
        no content sources are explicitly set it will default to completely \
        open." % self._directive

    def getRemediationDetail(self):
        return "Explicitly set a %s directive in your content policy." % self._directive


class WeakDefaultSource(BaseCSPIssue):

    """ Any `default-src' that is not 'none' 'self' or 'https:' """

    def getIssueName(self):
        return "Weak default-src Directive"

    def getIssueDetail(self):
        return "The default content source should be as restrictive as possible \
        the content policy for this website does not restrict the default source \
        to either 'none' 'self' (and 'https:')."

    def getRemediationDetail(self):
        return "Set the default-src to either 'self' or preferrably 'none'. If \
        the default source is set to 'self' also consider adding 'https:' to \
        ensure resources are loaded over a secure network connection."



class DeprecatedHeader(BaseCSPIssue):

    """ Flags use of `X-WebKit-CSP' and `X-Content-Security-Policy' """

    def getIssueName(self):
        return "Deprecated Header"

    def getIssueDetail(self):
        return "The site uses a deprecated CSP header"

    def getRemediationDetail(self):
        return "Change the server response header to `Content-Security-Policy'"


class ReportOnlyHeader(BaseCSPIssue):

    """ Flags use of `Content-Security-Policy-Report-Only' """

    def getIssueName(self):
        return "Report Only Header"

    def getIssueDetail(self):
        return "The site uses a CSP in report-only mode"

    def getRemediationDetail(self):
        return "Change the server response header to `Content-Security-Policy'"


class NonceContentSource(BaseCSPIssue):

    """ Alerts the user that a `nonce-' source was found """

    def getIssueName(self):
        return "Nonce Content Source"

    def getIssueDetail(self):
        return "This site uses nonces to secure inline content"

    def getRemediationDetail(self):
        return "Refactor the website to disallow all inline content, and remove \
        nonce content sources from the CSP."


class KnownCSPBypass(BaseCSPIssue):

    """ Reports a known bypass in a domain whitelisted by a CSP """

    # pylint: disable=W0231,R0913
    def __init__(self, httpService, url, httpMessages, severity, confidence,
                 directive=None, bypass=None):
        """
        Burp uses old style classes so we can't use super()
        """
        self._httpService = httpService
        self._url = url
        self._httpMessages = httpMessages
        self._severity = severity
        self._confidence = confidence
        self._directive = directive
        self._bypass = bypass

    def getIssueName(self):
        return "Known CSP Bypass: %s" % self._directive

    def getIssueDetail(self):
        return "A known bypass exists in the '%s' directive for the domain \
        '%s'. %s" % (self._directive, self._bypass[0], self._bypass[1])

    def getRemediationDetail(self):
        return "Remove the content source '%s' domain from your '%s' CSP \
        directive." % (self._bypass[0], self._directive)
"""
@author: moloch

This is a Burp plugin to parse Content-Security-Policy headers and detect
weaknesses and possibly bypasses in the policy.
"""
# pylint: disable=E0602,C0103,W0621,R0903,R0201


from httplib import HTTPResponse
from StringIO import StringIO
from urlparse import urlparse

from burp import IBurpExtender, IScannerCheck


class HttpDummySocket(object):

    """
    A dummy socket object so we can use httplib to parse the response bytearray
    """

    def __init__(self, byteResponse):
        self._file = StringIO(byteResponse)

    def makefile(self, *args, **kwargs):
        """ API compatability with `socket' """
        return self._file


class ContentSecurityPolicyScan(IScannerCheck):

    """ Implements the actual passive scan """

    def __init__(self, callbacks):
        """
        WARNING: Only one IScannerCheck object is ever created, because of this
        you effectively cannot use Python's `self' have to pass around any
        variables as method args if you want access to them, fml.
        """
        self._helpers = callbacks.getHelpers()

        # Checks must return a list of IScanIssue objects
        self._checks = [
            self.deprecatedHeaderCheck,
            self.reportOnlyHeaderCheck,
            self.unsafeContentSourceCheck,
            self.wildcardContentSourceCheck,
            self.wildcardSubdomainContentSourceCheck,
            self.insecureContentSourceCheck,
            self.nonceSourceCheck,
            self.missingDirectiveCheck,
            self.weakDefaultSourceCheck,
            self.knownBypassCheck,
        ]

    def _getUrl(self, burpHttpReqResp):
        """
        Uses the Burp helper APIs to get the URL from the HttpReqResp object
        """
        return self._helpers.analyzeRequest(burpHttpReqResp).getUrl()

    def doPassiveScan(self, burpHttpReqResp):
        """
        This is a callback method for Burp, its called for each HTTP req/resp.
        Returns a list of IScanIssue(s)
        """
        if len(burpHttpReqResp.getResponse()):
            return self.proccessHttpResponse(burpHttpReqResp)
        else:
            return []

    def consolidateDuplicateIssues(self, existingIssue, newIssue):
        """
        This is a callback method for Burp, and is used to cleanup duplicate
        findings.
        @return An indication of which issue(s) should be reported in the main
        Scanner results.
        <code>-1</code> to report the existing issue only
        <code>0</code> to report both issues
        <code>1</code> to report the new issue only
        """
        if existingIssue.getIssueName() == newIssue.getIssueName():
            return -1
        else:
            return 0

    def proccessHttpResponse(self, burpHttpReqResp):
        """ Processes only the HTTP repsonses with a CSP header """
        byteResponse = burpHttpReqResp.getResponse()
        httpSocket = HttpDummySocket(bytearray(byteResponse))
        response = HTTPResponse(httpSocket)
        response.begin()
        issues = []
        for header in response.getheaders():
            if header[0].lower() in ContentSecurityPolicy.HEADERS:
                findings = self.parseContentSecurityPolicy(header, burpHttpReqResp)
                issues.extend(findings)
        return issues

    def parseContentSecurityPolicy(self, cspHeader, burpHttpReqResp):
        """ Parses the CSP response header and searches for issues """
        csp = ContentSecurityPolicy(cspHeader[0], cspHeader[1])
        issues = []
        for check in self._checks:
            issues.extend(check(csp, burpHttpReqResp))
        return issues

    def deprecatedHeaderCheck(self, csp, burpHttpReqResp):
        """
        Checks for the use of a deprecated header such as `X-WebKit-CSP'
        """
        issues = []
        if csp.is_deprecated_header():
            deprecatedHeader = DeprecatedHeader(
                httpService=burpHttpReqResp.getHttpService(),
                url=self._getUrl(burpHttpReqResp),
                httpMessages=burpHttpReqResp,
                severity="Medium",
                confidence="Certain")
            issues.append(deprecatedHeader)
        return issues

    def reportOnlyHeaderCheck(self, csp, burpHttpReqResp):
        """
        Checks for the use of a report-only CSP header
        """
        issues = []
        if csp.is_report_only_mode():
            reportOnly = ReportOnlyHeader(
                httpService=burpHttpReqResp.getHttpService(),
                url=self._getUrl(burpHttpReqResp),
                httpMessages=burpHttpReqResp,
                severity="High",
                confidence="Certain")
            issues.append(reportOnly)
        return issues

    def unsafeContentSourceCheck(self, csp, burpHttpReqResp):
        """ Checks the current CSP header for unsafe content sources """
        issues = []
        for directive in [SCRIPT_SRC, STYLE_SRC]:
            if UNSAFE_EVAL in csp[directive] or UNSAFE_INLINE in csp[directive]:
                unsafeContent = UnsafeContentSource(
                    httpService=burpHttpReqResp.getHttpService(),
                    url=self._getUrl(burpHttpReqResp),
                    httpMessages=burpHttpReqResp,
                    severity="High",
                    confidence="Certain",
                    directive=directive)
                issues.append(unsafeContent)
        return issues

    def wildcardContentSourceCheck(self, csp, burpHttpReqResp):
        """
        Check content sources for wildcards '*' note that wilcard subdomains
        are checked by `wildcardSubdomainContentSourceCheck'
        """
        issues = []
        for directive, sources in csp.iteritems():
            if sources is None:
                continue  # Skip unspecified directives in NO_FALLBACK
            if any(src == "*" for src in sources):
                wildcardContent = WildcardContentSource(
                    httpService=burpHttpReqResp.getHttpService(),
                    url=self._getUrl(burpHttpReqResp),
                    httpMessages=burpHttpReqResp,
                    severity="Medium",
                    confidence="Certain",
                    directive=directive)
                issues.append(wildcardContent)
        return issues

    def wildcardSubdomainContentSourceCheck(self, csp, burpHttpReqResp):
        """ Check content sources for wildcards subdomains '*.foo.com' """
        issues = []
        for directive, sources in csp.iteritems():
            if sources is None:
                continue
            # This check is a little hacky but should work well
            # the shortest subdomain string should be like *.a.bc
            if any("*" in src and 5 <= len(src) for src in sources):
                wilcardSubdomain = WildcardSubdomainContentSource(
                    httpService=burpHttpReqResp.getHttpService(),
                    url=self._getUrl(burpHttpReqResp),
                    httpMessages=burpHttpReqResp,
                    severity="Low",
                    confidence="Certain",
                    directive=directive)
                issues.append(wilcardSubdomain)
        return issues

    def nonceSourceCheck(self, csp, burpHttpReqResp):
        """
        Check content sources for wildcards '*' note that wilcard subdomains
        are checked by `wildcardSubdomainContentSourceCheck'
        """
        issues = []
        for directive, sources in csp.iteritems():
            if sources is None:
                continue
            if any(src.startswith("'nonce-") for src in sources):
                nonceContent = NonceContentSource(
                    httpService=burpHttpReqResp.getHttpService(),
                    url=self._getUrl(burpHttpReqResp),
                    httpMessages=burpHttpReqResp,
                    severity="Informational",
                    confidence="Certain",
                    directive=directive)
                issues.append(nonceContent)
        return issues

    def insecureContentSourceCheck(self, csp, burpHttpReqResp):
        """ Check content sources that allow insecure network protocols """
        issues = []
        for directive, sources in csp.iteritems():
            if sources is None:
                continue
            for src in sources:
                if src == HTTP or urlparse(src).scheme in ["http", "ws"]:
                    insecureContent = InsecureContentDirective(
                        httpService=burpHttpReqResp.getHttpService(),
                        url=self._getUrl(burpHttpReqResp),
                        httpMessages=burpHttpReqResp,
                        severity="High",
                        confidence="Certain",
                        directive=directive)
                    issues.append(insecureContent)
        return issues

    def missingDirectiveCheck(self, csp, burpHttpReqResp):
        """
        Check for missing directives that do not inherit from `default-src'
        """
        issues = []
        for directive in ContentSecurityPolicy.NO_FALLBACK:
            if directive not in csp:
                missingDirective = MissingDirective(
                    httpService=burpHttpReqResp.getHttpService(),
                    url=self._getUrl(burpHttpReqResp),
                    httpMessages=burpHttpReqResp,
                    severity="Medium",
                    confidence="Certain",
                    directive=directive)
                issues.append(missingDirective)
        return issues

    def weakDefaultSourceCheck(self, csp, burpHttpReqResp):
        """
        Any `default-src' that is not 'none'/'self'/https: is considered weak
        """
        issues = []
        for contentSource in csp[DEFAULT_SRC]:
            if contentSource not in [SELF, NONE, HTTPS]:
                weakDefault = WeakDefaultSource(
                    httpService=burpHttpReqResp.getHttpService(),
                    url=self._getUrl(burpHttpReqResp),
                    httpMessages=burpHttpReqResp,
                    severity="Medium",
                    confidence="Certain")
                issues.append(weakDefault)
                break
        return issues

    def knownBypassCheck(self, csp, burpHttpReqResp):
        """
        Parses the CSP for known bypasses, this check is a little more
        complicated, and calls into other subroutines.
        """
        issues = []
        for directive, knownBypasses in CSP_KNOWN_BYPASSES.iteritems():
            bypasses = self._bypassCheckDirective(csp, directive, knownBypasses)
            for bypass in bypasses:
                bypassIssue = self._createBypassIssue(directive, bypass, burpHttpReqResp)
                issues.append(bypassIssue)
        return issues

    def _createBypassIssue(self, directive, bypass, burpHttpReqResp):
        """ Creates the KnownCSPBypass issue object """
        knownBypass = KnownCSPBypass(
            httpService=burpHttpReqResp.getHttpService(),
            url=self._getUrl(burpHttpReqResp),
            httpMessages=burpHttpReqResp,
            severity="High",
            confidence="Certain",
            directive=directive,
            bypass=bypass)
        return knownBypass

    def _bypassCheckDirective(self, csp, directive, knownBypasses):
        """
        Check an individual directive (e.g. `script-src') to see if it contains
        any domains that host known CSP bypasses.
        """
        bypasses = []
        for src in csp[directive]:
            if src.startswith("'") or src in [HTTP, HTTPS, DATA, BLOB]:
                continue  # We only care about domains

            # Iterate over all bypasses and check if `src' allows loading
            # content from `domain' if so, we have a bypass!
            for domain, payload in knownBypasses:
                if csp_match_domains(src, domain):
                    bypasses.append((domain, payload,))
        return bypasses


class BurpExtender(IBurpExtender):

    """ Burp extension object """

    NAME = "CSP Bypass"

    def	registerExtenderCallbacks(self, callbacks):
        """ Entrypoint and setup """
        callbacks.setExtensionName(self.NAME)
        callbacks.registerScannerCheck(ContentSecurityPolicyScan(callbacks))
        print '[*] CSP-Bypass extension loaded successfully.'
